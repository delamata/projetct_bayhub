# Bayhub Website

Site institucional elegante para locação de salas comerciais.

**Publicação via GitHub Pages:**
1. Suba os arquivos em um repositório público.
2. Vá em Settings > Pages.
3. Aponte para o branch `main` e pasta `/`.
4. Acesse via: `https://SEU_USUARIO.github.io/bayhub-site`